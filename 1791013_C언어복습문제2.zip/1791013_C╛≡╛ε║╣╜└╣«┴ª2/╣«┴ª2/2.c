﻿#include <stdio.h>

int oddsum1(int n);
int oddsum2(int n);
int oddsum3(int n);

int main() {
	int n = 100;
	int SUM = 0;

	for (int i = 0; i < n; i++) {
		SUM = SUM + oddsum1(i);
	}

	printf("(1) for oddsum1(%d) = %d\n", n, oddsum1(n));
	printf("(2) while oddsum1(%d) = %d\n", n, oddsum2(n));
	printf("(3) 재귀 oddsum1(%d) = %d\n", n, oddsum3(n));
	printf("(4) SUM = %d\n", SUM);
}

int oddsum1(int n) {
	int sum = 0;
	for (int i = 0; i = n; i++) {
		if (i % 2 != 0) {
			sum = sum + i;
		}
	}
	return sum;
}

int oddsum2(int n) {
	int sum = 0;
	int i = 0;;

	while (i < n) {
		if (i % 2 != 0) {
			sum = sum + i;
		}
	}
	return sum;
}

int oddsum3(int n) {
	if (n == 1)
		return 1;
	else
		return n + oddsum3(n - 2);
}