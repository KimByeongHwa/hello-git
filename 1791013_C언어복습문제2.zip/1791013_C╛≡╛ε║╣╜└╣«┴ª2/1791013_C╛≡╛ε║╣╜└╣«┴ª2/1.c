#include <stdio.h>

void forsum();
void whilesum();
void dowhilesum();


void main() {
	printf("(1) for ��� : "); forsum();
	printf("(2) while ��� : "); whilesum();
	printf("(3) do ~ while ��� : "); dowhilesum();
}

void forsum() {
	int sum = 0;
	for (int i = 1; i < 11; i++) {
		printf("%d ", i);
		sum = sum + i;
	}
	printf("sum=%d\n", sum);
}

void whilesum() {
	int i = 1;
	int sum = 0;
	while (i < 11) {
		printf("%d ", i);
		sum = sum + i;
		i++;
	}
	printf("sum=%d\n", sum);
}

void dowhilesum() {
	int i = 1;
	int sum = 0;
	do {
		printf("%d ", i);
		sum = sum + i;
		i++;
	} while (i < 11);
	printf("sum=%d\n", sum);
}